"use strict";
cc._RF.push(module, 'b090d2Or11OjJN6DIiTKNGU', 'amPlayer');
// Script/player/amPlayer.js

"use strict";

var amPlayer = function amPlayer(config) {
  var _config = config || {};_config.useWorker = !(_config.useWorker === false);var self = this;var reuseMemory = true;var haveAudio = _config.haveAudio || false;_config.lender = _config.lender || true;if (!this.player) {
    this.player = new Player({ useWorker: _config.useWorker, webgl: _config.webgl, reuseMemory: reuseMemory, workerFile: _config.workerFile, render: _config.lender });var divElement = document.getElementById(_config.divId);if (divElement && this.player.canvas) {
      divElement.appendChild(this.player.canvas);
    }this.canvas = this.player.canvas;this.player.onplay = self.onplay;this.player.onPictureDecoded = self.onPictureDecoded;
  }this.flvsu = function (tag) {
    switch (tag.type) {case 8:
        break;case 9:
        this.player.decode(tag.data, { timestamp: new Date().getTime() });break;case 18:
        break;}
  };this.flv = new Flv(haveAudio);this.decode = function (data) {
    this.flv.parse(data, function (tag) {
      self.flvsu(tag);
    });
  };this.playing = false;
};amPlayer.prototype = { play: function play(wsUri) {
    var reconnectMs = 3000;this.stop();if (wsUri != null) {
      this.wsUri = wsUri;
    } else {
      wsUri = this.wsUri;
    }var ws = new WebSocket(wsUri);this.ws = ws;ws.binaryType = "arraybuffer";var self = this;ws.onopen = function (e) {
      console.log("Streamwebsocket connected");self.nclose = false;
    };ws.onmessage = function (msg) {
      self.decode(msg.data);
    };ws.onclose = function (e) {
      console.log("Streamwebsocket disconnected");if (self.playing == true) {
        self.playing = false;self.onstop();
      }if (self.nclose) {
        return;
      }if (reconnectMs > 0) {
        console.log("reconnect");setTimeout(function () {
          self.play(wsUri);
        }, reconnectMs);
      }
    };
  }, stop: function stop() {
    if (this.ws) {
      this.nclose = true;this.ws.close();this.ws = null;
    }
  }, onPictureDecoded: function onPictureDecoded(buffer, width, height, infos) {}, onplay: function onplay() {}, onstop: function onstop() {} };var YUVCanvas = function YUVCanvas(parOptions) {
  parOptions = parOptions || {};this.canvasElement = parOptions.canvas || document.createElement("canvas");this.contextOptions = parOptions.contextOptions;this.type = parOptions.type || "yuv420";this.customYUV444 = parOptions.customYUV444;this.conversionType = parOptions.conversionType || "rec601";this.width = parOptions.width || 640;
  this.height = parOptions.height || 320;this.animationTime = parOptions.animationTime || 0;this.canvasElement.width = this.width;this.canvasElement.height = this.height;this.initContextGL();if (this.contextGL) {
    this.initProgram();this.initBuffers();this.initTextures();
  }if (this.type === "yuv420") {
    this.drawNextOuptutPictureGL = function (par) {
      var gl = this.contextGL;var texturePosBuffer = this.texturePosBuffer;var uTexturePosBuffer = this.uTexturePosBuffer;var vTexturePosBuffer = this.vTexturePosBuffer;var yTextureRef = this.yTextureRef;var uTextureRef = this.uTextureRef;var vTextureRef = this.vTextureRef;var yData = par.yData;var uData = par.uData;var vData = par.vData;var width = this.width;var height = this.height;var yDataPerRow = par.yDataPerRow || width;var yRowCnt = par.yRowCnt || height;var uDataPerRow = par.uDataPerRow || width / 2;var uRowCnt = par.uRowCnt || height / 2;var vDataPerRow = par.vDataPerRow || uDataPerRow;var vRowCnt = par.vRowCnt || uRowCnt;gl.viewport(0, 0, width, height);var tTop = 0;var tLeft = 0;var tBottom = height / yRowCnt;var tRight = width / yDataPerRow;var texturePosValues = new Float32Array([tRight, tTop, tLeft, tTop, tRight, tBottom, tLeft, tBottom]);gl.bindBuffer(gl.ARRAY_BUFFER, texturePosBuffer);gl.bufferData(gl.ARRAY_BUFFER, texturePosValues, gl.DYNAMIC_DRAW);if (this.customYUV444) {
        tBottom = height / uRowCnt;tRight = width / uDataPerRow;
      } else {
        tBottom = height / 2 / uRowCnt;tRight = width / 2 / uDataPerRow;
      }var uTexturePosValues = new Float32Array([tRight, tTop, tLeft, tTop, tRight, tBottom, tLeft, tBottom]);gl.bindBuffer(gl.ARRAY_BUFFER, uTexturePosBuffer);gl.bufferData(gl.ARRAY_BUFFER, uTexturePosValues, gl.DYNAMIC_DRAW);if (this.customYUV444) {
        tBottom = height / vRowCnt;tRight = width / vDataPerRow;
      } else {
        tBottom = height / 2 / vRowCnt;tRight = width / 2 / vDataPerRow;
      }var vTexturePosValues = new Float32Array([tRight, tTop, tLeft, tTop, tRight, tBottom, tLeft, tBottom]);gl.bindBuffer(gl.ARRAY_BUFFER, vTexturePosBuffer);gl.bufferData(gl.ARRAY_BUFFER, vTexturePosValues, gl.DYNAMIC_DRAW);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D, yTextureRef);gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, yDataPerRow, yRowCnt, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, yData);
      gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D, uTextureRef);gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, uDataPerRow, uRowCnt, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, uData);gl.activeTexture(gl.TEXTURE2);gl.bindTexture(gl.TEXTURE_2D, vTextureRef);gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, vDataPerRow, vRowCnt, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, vData);gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    };
  } else {
    if (this.type === "yuv422") {
      this.drawNextOuptutPictureGL = function (par) {
        var gl = this.contextGL;var texturePosBuffer = this.texturePosBuffer;var textureRef = this.textureRef;var data = par.data;var width = this.width;var height = this.height;var dataPerRow = par.dataPerRow || width * 2;var rowCnt = par.rowCnt || height;gl.viewport(0, 0, width, height);var tTop = 0;var tLeft = 0;var tBottom = height / rowCnt;var tRight = width / (dataPerRow / 2);var texturePosValues = new Float32Array([tRight, tTop, tLeft, tTop, tRight, tBottom, tLeft, tBottom]);gl.bindBuffer(gl.ARRAY_BUFFER, texturePosBuffer);gl.bufferData(gl.ARRAY_BUFFER, texturePosValues, gl.DYNAMIC_DRAW);gl.uniform2f(gl.getUniformLocation(this.shaderProgram, "resolution"), dataPerRow, height);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D, textureRef);gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, dataPerRow, rowCnt, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, data);gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      };
    }
  }
};YUVCanvas.prototype.isWebGL = function () {
  return this.contextGL;
};YUVCanvas.prototype.initContextGL = function () {
  this.contextGL = getWebGL(this.canvasElement, this.contextOptions);
};YUVCanvas.prototype.initProgram = function () {
  var gl = this.contextGL;var vertexShaderScript;var fragmentShaderScript;if (this.type === "yuv420") {
    vertexShaderScript = ["attribute vec4 vertexPos;", "attribute vec4 texturePos;", "attribute vec4 uTexturePos;", "attribute vec4 vTexturePos;", "varying vec2 textureCoord;", "varying vec2 uTextureCoord;", "varying vec2 vTextureCoord;", "void main()", "{", "  gl_Position = vertexPos;", "  textureCoord = texturePos.xy;", "  uTextureCoord = uTexturePos.xy;", "  vTextureCoord = vTexturePos.xy;", "}"].join("\n");
    fragmentShaderScript = ["precision highp float;", "varying highp vec2 textureCoord;", "varying highp vec2 uTextureCoord;", "varying highp vec2 vTextureCoord;", "uniform sampler2D ySampler;", "uniform sampler2D uSampler;", "uniform sampler2D vSampler;", "uniform mat4 YUV2RGB;", "void main(void) {", "  highp float y = texture2D(ySampler,  textureCoord).r;", "  highp float u = texture2D(uSampler,  uTextureCoord).r;", "  highp float v = texture2D(vSampler,  vTextureCoord).r;", "  gl_FragColor = vec4(y, u, v, 1) * YUV2RGB;", "}"].join("\n");
  } else {
    if (this.type === "yuv422") {
      vertexShaderScript = ["attribute vec4 vertexPos;", "attribute vec4 texturePos;", "varying vec2 textureCoord;", "void main()", "{", "  gl_Position = vertexPos;", "  textureCoord = texturePos.xy;", "}"].join("\n");fragmentShaderScript = ["precision highp float;", "varying highp vec2 textureCoord;", "uniform sampler2D sampler;", "uniform highp vec2 resolution;", "uniform mat4 YUV2RGB;", "void main(void) {", "  highp float texPixX = 1.0 / resolution.x;", "  highp float logPixX = 2.0 / resolution.x;", "  highp float logHalfPixX = 4.0 / resolution.x;", "  highp float steps = floor(textureCoord.x / logPixX);", "  highp float uvSteps = floor(textureCoord.x / logHalfPixX);", "  highp float y = texture2D(sampler, vec2((logPixX * steps) + texPixX, textureCoord.y)).r;", "  highp float u = texture2D(sampler, vec2((logHalfPixX * uvSteps), textureCoord.y)).r;", "  highp float v = texture2D(sampler, vec2((logHalfPixX * uvSteps) + texPixX + texPixX, textureCoord.y)).r;", "  gl_FragColor = vec4(y, u, v, 1.0) * YUV2RGB;", "}"].join("\n");
    }
  }var YUV2RGB = [];if (this.conversionType == "rec709") {
    YUV2RGB = [1.16438, 0, 1.79274, -0.97295, 1.16438, -0.21325, -0.53291, 0.30148, 1.16438, 2.1124, 0, -1.1334, 0, 0, 0, 1];
  } else {
    YUV2RGB = [1.16438, 0, 1.59603, -0.87079, 1.16438, -0.39176, -0.81297, 0.52959, 1.16438, 2.01723, 0, -1.08139, 0, 0, 0, 1];
  }var vertexShader = gl.createShader(gl.VERTEX_SHADER);gl.shaderSource(vertexShader, vertexShaderScript);gl.compileShader(vertexShader);if (!gl.getShaderParameter(vertexShader, gl.COMPILE_STATUS)) {
    console.log("Vertex shader failed to compile: " + gl.getShaderInfoLog(vertexShader));
  }var fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);gl.shaderSource(fragmentShader, fragmentShaderScript);gl.compileShader(fragmentShader);if (!gl.getShaderParameter(fragmentShader, gl.COMPILE_STATUS)) {
    console.log("Fragment shader failed to compile: " + gl.getShaderInfoLog(fragmentShader));
  }var program = gl.createProgram();gl.attachShader(program, vertexShader);gl.attachShader(program, fragmentShader);gl.linkProgram(program);if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    console.log("Program failed to compile: " + gl.getProgramInfoLog(program));
  }gl.useProgram(program);var YUV2RGBRef = gl.getUniformLocation(program, "YUV2RGB");gl.uniformMatrix4fv(YUV2RGBRef, false, YUV2RGB);this.shaderProgram = program;
};YUVCanvas.prototype.initBuffers = function () {
  var gl = this.contextGL;var program = this.shaderProgram;var vertexPosBuffer = gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER, vertexPosBuffer);gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([1, 1, -1, 1, 1, -1, -1, -1]), gl.STATIC_DRAW);var vertexPosRef = gl.getAttribLocation(program, "vertexPos");gl.enableVertexAttribArray(vertexPosRef);gl.vertexAttribPointer(vertexPosRef, 2, gl.FLOAT, false, 0, 0);if (this.animationTime) {
    var animationTime = this.animationTime;var timePassed = 0;var stepTime = 15;var aniFun = function aniFun() {
      timePassed += stepTime;var mul = 1 * timePassed / animationTime;if (timePassed >= animationTime) {
        mul = 1;
      } else {
        setTimeout(aniFun, stepTime);
      }var neg = -1 * mul;var pos = 1 * mul;var vertexPosBuffer = gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER, vertexPosBuffer);gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([pos, pos, neg, pos, pos, neg, neg, neg]), gl.STATIC_DRAW);var vertexPosRef = gl.getAttribLocation(program, "vertexPos");gl.enableVertexAttribArray(vertexPosRef);gl.vertexAttribPointer(vertexPosRef, 2, gl.FLOAT, false, 0, 0);try {
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      } catch (e) {}
    };aniFun();
  }var texturePosBuffer = gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER, texturePosBuffer);gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([1, 0, 0, 0, 1, 1, 0, 1]), gl.STATIC_DRAW);var texturePosRef = gl.getAttribLocation(program, "texturePos");
  gl.enableVertexAttribArray(texturePosRef);gl.vertexAttribPointer(texturePosRef, 2, gl.FLOAT, false, 0, 0);this.texturePosBuffer = texturePosBuffer;if (this.type === "yuv420") {
    var uTexturePosBuffer = gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER, uTexturePosBuffer);gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([1, 0, 0, 0, 1, 1, 0, 1]), gl.STATIC_DRAW);var uTexturePosRef = gl.getAttribLocation(program, "uTexturePos");gl.enableVertexAttribArray(uTexturePosRef);gl.vertexAttribPointer(uTexturePosRef, 2, gl.FLOAT, false, 0, 0);this.uTexturePosBuffer = uTexturePosBuffer;var vTexturePosBuffer = gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER, vTexturePosBuffer);gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([1, 0, 0, 0, 1, 1, 0, 1]), gl.STATIC_DRAW);var vTexturePosRef = gl.getAttribLocation(program, "vTexturePos");gl.enableVertexAttribArray(vTexturePosRef);gl.vertexAttribPointer(vTexturePosRef, 2, gl.FLOAT, false, 0, 0);this.vTexturePosBuffer = vTexturePosBuffer;
  }
};YUVCanvas.prototype.initTextures = function () {
  var gl = this.contextGL;var program = this.shaderProgram;if (this.type === "yuv420") {
    var yTextureRef = this.initTexture();var ySamplerRef = gl.getUniformLocation(program, "ySampler");gl.uniform1i(ySamplerRef, 0);this.yTextureRef = yTextureRef;var uTextureRef = this.initTexture();var uSamplerRef = gl.getUniformLocation(program, "uSampler");gl.uniform1i(uSamplerRef, 1);this.uTextureRef = uTextureRef;var vTextureRef = this.initTexture();var vSamplerRef = gl.getUniformLocation(program, "vSampler");gl.uniform1i(vSamplerRef, 2);this.vTextureRef = vTextureRef;
  } else {
    if (this.type === "yuv422") {
      var textureRef = this.initTexture();var samplerRef = gl.getUniformLocation(program, "sampler");gl.uniform1i(samplerRef, 0);this.textureRef = textureRef;
    }
  }
};YUVCanvas.prototype.initTexture = function () {
  var gl = this.contextGL;var textureRef = gl.createTexture();gl.bindTexture(gl.TEXTURE_2D, textureRef);gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);gl.bindTexture(gl.TEXTURE_2D, null);return textureRef;
};YUVCanvas.prototype.drawNextOutputPicture = function (width, height, croppingParams, data) {
  var gl = this.contextGL;if (gl) {
    this.drawNextOuptutPictureGL(width, height, croppingParams, data);
  } else {
    this.drawNextOuptutPictureRGBA(width, height, croppingParams, data);
  }
};YUVCanvas.prototype.drawNextOuptutPictureRGBA = function (width, height, croppingParams, data) {
  var canvas = this.canvasElement;var croppingParams = null;var argbData = data;var ctx = canvas.getContext("2d");var imageData = ctx.getImageData(0, 0, width, height);imageData.data.set(argbData);if (croppingParams === null) {
    ctx.putImageData(imageData, 0, 0);
  } else {
    ctx.putImageData(imageData, -croppingParams.left, -croppingParams.top, 0, 0, croppingParams.width, croppingParams.height);
  }
};function getWebGL(canvas, contextOptions) {
  var gl = null;var validContextNames = ["webgl", "experimental-webgl", "moz-webgl", "webkit-3d"];var nameIndex = 0;while (!gl && nameIndex < validContextNames.length) {
    var contextName = validContextNames[nameIndex];try {
      if (contextOptions) {
        gl = canvas.getContext(contextName, this.contextOptions);
      } else {
        gl = canvas.getContext(contextName);
      }
    } catch (e) {
      gl = null;
    }if (!gl || typeof gl.getParameter !== "function") {
      gl = null;
    }++nameIndex;
  }return gl;
}var Flv = function Flv(haveAudio) {
  this.haveAudio = haveAudio;
};Flv.prototype = { H264Header: new Uint8Array([0, 0, 0, 1]), TAG_TYPE_AUDIO: 8, TAG_TYPE_VIDEO: 9, TAG_TYPE_META: 18, parse: function parse(buffer, f) {
    this.bytes = new Uint8Array(buffer);var o = {},
        offset = 0;if (this.bytes[0] == 70) {
      o.header = {};offset += 3;offset++;offset++;offset += 4;offset += 4;
    }o.tags = [];while (offset < this.bytes.length) {
      var tag = {};tag.type = this.ui8(offset);offset++;tag.bodyLength = this.ui24(offset);offset += 3;offset += 3;offset++;offset += 3;if (tag.type == this.TAG_TYPE_VIDEO) {
        tag.data = this.createH264(offset);
      } else {
        if (tag.type == this.TAG_TYPE_AUDIO) {
          if (this.haveAudio) {
            tag.data = this.createAudio(this.bytes.subarray(offset + 2, offset + tag.bodyLength), this.ui8(offset + 1));
          }
        }
      }offset += tag.bodyLength;offset += 4;
      f(tag);
    }
  }, createAudio: function createAudio(data, frame_type) {
    if (frame_type == 0) {
      var audioObjectType = (data[0] & 248) >> 3;var samplingFrequencyIndex = (data[0] & 7) << 1 | data[1] >> 7;var channelConfig = data[1] >> 3 & 15;var frameLengthFlag = data[1] >> 2 & 1;var dependsOnCoreCoder = data[1] >> 1 & 1;var extensionFlag = data[1] & 1;var adtsHeader = new Uint8Array(7);adtsHeader[0] = 255;adtsHeader[1] = 240;adtsHeader[1] |= 0 << 3;adtsHeader[1] |= 0 << 1;adtsHeader[1] |= 1;adtsHeader[2] = audioObjectType - 1 << 6;adtsHeader[2] |= (samplingFrequencyIndex & 15) << 2;adtsHeader[2] |= 0 << 1;adtsHeader[2] |= (channelConfig & 4) >> 2;adtsHeader[3] = (channelConfig & 3) << 6;adtsHeader[3] |= 0 << 5;adtsHeader[3] |= 0 << 4;adtsHeader[3] |= 0 << 3;adtsHeader[3] |= 0 << 2;var adtsLen = 7;adtsHeader[3] |= (adtsLen & 6144) >> 11;adtsHeader[4] = (adtsLen & 2040) >> 3;adtsHeader[5] = (adtsLen & 7) << 5;adtsHeader[5] |= 31;adtsHeader[6] = 252;this.adtsHeader = adtsHeader;return;
    }if (frame_type == 1) {
      var adtsLen = data.byteLength + 7;var adtsHeader = this.adtsHeader;adtsHeader[3] |= (adtsLen & 6144) >> 11;adtsHeader[4] = (adtsLen & 2040) >> 3;adtsHeader[5] = (adtsLen & 7) << 5;adtsHeader[5] |= 31;adtsHeader[6] = 252;var body = new Uint8Array(adtsLen);body.set(adtsHeader, 0);body.set(data, 7);return body;
    }
  }, createH264: function createH264(offset) {
    var frame_type = this.bytes[0 + offset];var codec_id = frame_type & 15;frame_type = frame_type >> 4 & 15;var sps, pps;var ret;if (codec_id == 7) {
      if (frame_type == 1 && this.bytes[1 + offset] == 0) {
        var spsNum = this.bytes[10 + offset] & 31;if (spsNum == 1) {
          var spsLen = this.ui16(11 + offset);sps = this.bytes.subarray(13 + offset, 13 + offset + spsLen);var ppsNum = this.bytes[13 + offset + spsLen] & 31;if (ppsNum == 1) {
            var ppsLen = this.ui16(14 + offset + spsLen);pps = this.bytes.subarray(16 + offset + spsLen, 16 + offset + spsLen + ppsLen);var len = pps.length + sps.length + 8;ret = new Uint8Array(len);ret.set(this.H264Header, 0);ret.set(sps, 4);ret.set(this.H264Header, sps.length + 4);ret.set(pps, sps.length + 8);
          }
        }
      } else {
        offset += 5;var len = this.uint32(this.bytes, offset);offset += 4;var nal = this.bytes.subarray(offset, offset + len);len = len + 4;ret = new Uint8Array(len);ret.set(this.H264Header, 0);ret.set(nal, 4);
      }
    }return ret;
  }, ui8: function ui8(offset) {
    return this.bytes[offset];
  }, ui16: function ui16(offset) {
    return this.bytes[offset] << 8 | this.bytes[offset + 1];
  }, ui24: function ui24(offset) {
    return this.bytes[offset] << 16 | this.bytes[offset + 1] << 8 | this.bytes[offset + 2];
  }, ui32: function ui32(offset) {
    return this.bytes[offset] << 24 | this.bytes[offset + 1] << 16 | this.bytes[offset + 2] << 8 | this.bytes[offset + 3];
  }, uint32: function uint32(bytes, offset) {
    return bytes[offset] << 24 | bytes[offset + 1] << 16 | bytes[offset + 2] << 8 | bytes[offset + 3];
  }, str: function str(offset, n) {
    var ret = [];for (var i = offset, end = offset + n; i < end; ++i) {
      ret[ret.length] = this.bytes[i];
    }return String.fromCharCode.apply(null, ret);
  } };var nowValue = function nowValue() {
  return new Date().getTime();
};if (typeof performance != "undefined") {
  if (performance.now) {
    nowValue = function nowValue() {
      return performance.now();
    };
  }
}var Player = function Player(parOptions) {
  var self = this;this._config = parOptions || {};this.render = true;if (this._config.render === false) {
    this.render = false;
  }this.nowValue = nowValue;this._config.workerFile = this._config.workerFile || "js/Decoder.js";if (this._config.preserveDrawingBuffer) {
    this._config.contextOptions = this._config.contextOptions || {};this._config.contextOptions.preserveDrawingBuffer = true;
  }var webgl = "auto";if (this._config.webgl === true) {
    webgl = true;
  } else {
    if (this._config.webgl === false) {
      webgl = false;
    }
  }if (webgl == "auto") {
    webgl = true;try {
      if (!window.WebGLRenderingContext) {
        webgl = false;
      } else {
        var canvas = document.createElement("canvas");var ctx = getWebGL(canvas);if (!ctx) {
          webgl = false;
        }
      }
    } catch (e) {
      webgl = false;
    }
  }console.log("webgl", webgl);this.webgl = webgl;if (this.webgl) {
    this.renderFrame = this.renderFrameWebGL;
  } else {
    this.renderFrame = this.renderFrameRGB;
  }this.isplaying = false;var onPictureDecoded = function onPictureDecoded(buffer, width, height, infos) {
    self.onPictureDecoded(buffer, width, height, infos);if (!buffer || !self.render) {
      return;
    }self.renderFrame({ canvasObj: self.canvasObj, data: buffer, width: width, height: height });if (self.isplaying == false) {
      self.isplaying = true;self.onplay();
    }if (self.onRenderFrameComplete) {
      self.onRenderFrameComplete({ data: buffer, width: width, height: height, infos: infos, canvasObj: self.canvasObj });
    }
  };if (!this._config.size) {
    this._config.size = {};
  }this._config.size.width = this._config.size.width || 480;this._config.size.height = this._config.size.height || 320;if (this._config.useWorker) {
    var worker = new Worker(this._config.workerFile);this.worker = worker;worker.addEventListener("message", function (e) {
      var data = e.data;if (data.consoleLog) {
        console.log(data.consoleLog);if (window.debug) {
          window.debug.value = data.consoleLog;
        }return;
      }onPictureDecoded.call(self, new Uint8Array(data.buf, 0, data.length), data.width, data.height, data.infos);
    }, false);worker.postMessage({ type: "Broadway.js - Worker init", options: { rgb: !webgl, memsize: this.memsize, reuseMemory: this._config.reuseMemory ? true : false } });if (!this._config.transferMemory) {
      this.decode = function (parData, parInfo) {
        worker.postMessage({ buf: parData.buffer, offset: parData.byteOffset, length: parData.length, info: parInfo }, [parData.buffer]);
      };
    } else {
      this.decode = function (parData, parInfo) {
        var copyU8 = new Uint8Array(parData);worker.postMessage({ buf: copyU8.buffer, offset: 0, length: parData.length, info: parInfo }, [copyU8.buffer]);
      };
    }if (this._config.reuseMemory) {
      this.recycleMemory = function (parArray) {
        worker.postMessage({ reuse: parArray.buffer }, [parArray.buffer]);
      };
    }
  } else {
    this.decoder = new Decoder({ rgb: !webgl });this.decoder.onPictureDecoded = onPictureDecoded;this.decode = function (parData, parInfo) {
      self.decoder.decode(parData, parInfo);
    };
  }if (this.render) {
    this.canvasObj = this.createCanvas({ contextOptions: this._config.contextOptions }, this.webgl);this.canvas = this.canvasObj.canvas;
  }this.domNode = this.canvas;
};Player.prototype = { onPictureDecoded: function onPictureDecoded(buffer, width, height, infos) {}, recycleMemory: function recycleMemory(buf) {}, createCanvas: function createCanvas(options, iswebgl) {
    var canvasObj = this._createBasicCanvasObj(options);if (iswebgl) {
      canvasObj.contextOptions = options.contextOptions;
    }return canvasObj;
  }, _createBasicCanvasObj: function _createBasicCanvasObj(options) {
    options = options || {};var obj = {};var width = options.width;if (!width) {
      width = this._config.size.width;
    }var height = options.height;if (!height) {
      height = this._config.size.height;
    }obj.canvas = document.createElement("canvas");
    obj.canvas.width = width;obj.canvas.height = height;obj.canvas.style = "background-color:#0D0E1B;height:100%;width:100%;";return obj;
  }, renderFrameWebGL: function renderFrameWebGL(options) {
    var canvasObj = options.canvasObj;var width = options.width || canvasObj.canvas.width;var height = options.height || canvasObj.canvas.height;var self = this;if (canvasObj.canvas.width !== width || canvasObj.canvas.height !== height || !canvasObj.webGLCanvas) {
      canvasObj.canvas.width = width;canvasObj.canvas.height = height;canvasObj.webGLCanvas = new YUVCanvas({ canvas: canvasObj.canvas, contextOptions: canvasObj.contextOptions, width: width, height: height });self.isplaying == false;
    }var ylen = width * height;var uvlen = width / 2 * (height / 2);canvasObj.webGLCanvas.drawNextOutputPicture({ yData: options.data.subarray(0, ylen), uData: options.data.subarray(ylen, ylen + uvlen), vData: options.data.subarray(ylen + uvlen, ylen + uvlen + uvlen) });self.recycleMemory(options.data);
  }, renderFrameRGB: function renderFrameRGB(options) {
    var canvasObj = options.canvasObj;var width = options.width || canvasObj.canvas.width;var height = options.height || canvasObj.canvas.height;var self = this;if (canvasObj.canvas.width !== width || canvasObj.canvas.height !== height) {
      canvasObj.canvas.width = width;canvasObj.canvas.height = height;self.isplaying == false;
    }var ctx = canvasObj.ctx;var imgData = canvasObj.imgData;if (!ctx) {
      canvasObj.ctx = canvasObj.canvas.getContext("2d");ctx = canvasObj.ctx;canvasObj.imgData = ctx.createImageData(width, height);imgData = canvasObj.imgData;
    }imgData.data.set(options.data);ctx.putImageData(imgData, 0, 0);self.recycleMemory(options.data);
  } };module.exports = amPlayer;

cc._RF.pop();