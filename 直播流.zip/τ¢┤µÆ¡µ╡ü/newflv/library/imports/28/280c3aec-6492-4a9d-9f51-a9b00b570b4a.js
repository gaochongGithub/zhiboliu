"use strict";
cc._RF.push(module, '280c3rsZJJKnZ9RqbALVwtK', 'HelloWorld');
// Script/HelloWorld.js

'use strict';

//如果是发布webgl需要在main.js的加入一句
//cc.macro.ENABLE_TRANSPARENT_CANVAS = true; //cc.game.run(option, onStart);这之前
//Decoder.js,flv.min.js导入为插件,其他文件为require
//发布选择canvas模式,如果是
var livePlayer = require("livePlayer");

cc.Class({
    extends: cc.Component,

    properties: {
        btnplay: {
            default: null,
            type: cc.Button
        },
        btnstop: {
            default: null,
            type: cc.Button
        },
        btnchange: {
            default: null,
            type: cc.Button
        }

    },

    // use this for initialization
    onLoad: function onLoad() {
        cc._initDebugSetting(cc.DebugMode.INFO);
        this.btnplay.node.on('click', this.onclick, this);
        this.btnstop.node.on('click', this.onclick, this);
        this.btnchange.node.on('click', this.onclick, this);
        //console.log(cc.url.raw('Script/player/Decoder.js'))
        //this.liveVideo = this.node.getComponent("livePlayer");

        this.liveVideo = this.node.addComponent(livePlayer);
        this.liveVideo.setSize(0, 0, 960, 640);
        this.liveVideo.play("ws://23.99.125.208:8081/gw/bjl012.flv");
        //第二个
        //this.liveVideo2 = this.node.addComponent(livePlayer);

        this.home = 1;
    },

    update: function update(dt) {},

    onclick: function onclick(event) {
        var btn = event.detail;
        if (btn == this.btnplay) {
            this.liveVideo.play("ws://23.99.125.208:8081/gw/bjl012.flv");
        } else if (btn == this.btnstop) {
            this.liveVideo.stop();
        } else if (btn == this.btnchange) {
            //换房间
            //cc.director.loadScene("helloworld");
            this.home = this.home % 6 + 1;
            this.liveVideo.play("ws://23.99.125.208:8081/gw/bjl0" + this.home + "1.flv");
        }
        //this.liveVideo.play("ws://tw.002cdn.com/obs/02M.flv");
    }
});

cc._RF.pop();