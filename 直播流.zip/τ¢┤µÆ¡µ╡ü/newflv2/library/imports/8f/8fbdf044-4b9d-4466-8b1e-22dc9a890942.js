"use strict";
cc._RF.push(module, '8fbdfBES51EZoseItyaiQlC', 'audio');
// Script/audio.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        audio: {
            url: cc.AudioClip,
            default: null
        }
    },

    onLoad: function onLoad() {
        this.current = cc.audioEngine.play(this.audio, true, 1);
        //this.audio.play();
    },

    onDestroy: function onDestroy() {
        cc.audioEngine.stop(this.current);
        //this.audio.stop();
    }
});

cc._RF.pop();