"use strict";
cc._RF.push(module, 'a72c2LnFx9OfKhdnHukO5E1', 'AmPlayer');
// Script/player/AmPlayer.js

'use strict';

var amPlayer = function amPlayer(hasAudio) {
    this.hasAudio = hasAudio;
    var video = document.createElement("canvas");
    this.video = video;

    video.style.backgroundColor = '0D0E1B';
    video.style.width = '100%';
    video.style.height = '100%';
    this.player = null;
};

amPlayer.prototype = {
    init: function init() {
        var self = this;
        var player = this.player;
        if (!player) {
            player = new Module.AnPlayer();
            this.player = player;
            player.onOpen = function (arg) {
                out("onOpen");
                //var name = url.value.split("/")[4];
                //player.send("[\"__play\",\"" + name + "\"]");           
            };
            player.onClose = function (arg) {
                out("onClose");
                setTimeout(function () {
                    self.play();
                }, 3000);
            };
            player.onMessage = function (arg) {
                console.log(arg);
            };

            player.bufferTime = 500;
            player.hasAudio = false;
            player.setCanvas(this.video);
        }
    },
    stop: function stop() {
        var player = this.player;
        if (player) {
            player.stop();
        }
    },
    play: function play(url) {
        this.init();
        if (url != null) {
            this.url = 'ws://' + url;
        }

        this.player.connect(this.url);
    }

};

out = function out(e) {
    //document.getElementById("log").innerHTML += e + "<br>";
    console.log(e);
};

if (typeof module != 'undefined') {
    module.exports = amPlayer;
};

cc._RF.pop();