(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/player/livePlayer.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '7d123lf8qdJRZoinDfNHbdM', 'livePlayer', __filename);
// Script/player/livePlayer.js

"use strict";

//如果是发布webgl需要在main.js的加入一句
//cc.macro.ENABLE_TRANSPARENT_CANVAS = true; //cc.game.run(option, onStart);这之前
//AnPlayer.js,flv.min.js导入为插件,livePlayer为require

var amPlayer = require("amPlayer");

var livePlayer = cc.Class({
    extends: cc.Component,
    properties: {
        x: 0,
        y: 0,
        width: 960,
        height: 640,
        url: ""
        // videoSprite: {
        //     default: null,
        //     type: cc.Sprite
        // }

    },

    onLoad: function onLoad() {
        //cc.director.setClearColor(new cc.Color(0, 0, 0, 0));
        //设置canvas脏矩形优化
        if (cc._renderType === cc.game.RENDER_TYPE_CANVAS) {
            cc.renderer.enableDirtyRegion(false);
            //cc.log("RENDER_TYPE_CANVAS");
        } else {
                //cc.log("RENDER_TYPE_WEBGL");
            }

        this.dt = 0;
        this.initPlayer();
    },

    initPlayer: function initPlayer() {
        var Sys = {};
        var ua = navigator.userAgent.toLowerCase();
        var s;
        //(s = ua.match(/msie ([\d.]+)/)) ? Sys.ie = s[1] :
        //(s = ua.match(/firefox\/([\d.]+)/)) ? Sys.firefox = s[1] :
        //(s = ua.match(/chrome\/([\d.]+)/)) ? Sys.chrome = s[1] :
        //(s = ua.match(/opera.([\d.]+)/)) ? Sys.opera = s[1] :
        (s = ua.match(/version\/([\d.]+).*safari/)) ? Sys.safari = s[1] : 0;
        //alert(Sys.safari) 

        var isSupported = flvjs.isSupported();
        cc.log("isSupported:", isSupported);
        if (isSupported) {
            //&& Sys.safari
            var player = new flvPlayer();
            this.player = player;
            this.video = player.video;
        } else {

            var player = new amPlayer();
            this.player = player;
            this.video = player.video;
        }

        this.putInContainer(this.video);
    },
    play: function play(url) {
        if (url == null) {
            url = this.url;
        }
        this.url = url;
        this.player.play(url);
    },
    stop: function stop() {
        this.player.stop();
    },
    onDestroy: function onDestroy() {
        cc.log("live destroy");
        this.stop();
        this.player.destroy();

        this.container.parentNode.removeChild(this.container);
        window.removeEventListener("resize", this.resizeEventVar, false);
    },
    // called every frame
    update: function update(dt) {
        //this.paintVideo(dt);

    },

    initTexture: function initTexture(dom) {
        var texture2d = new cc.Texture2D();
        texture2d.initWithElement(dom);
        //texture2d.handleLoadedTexture();
        this.videoSprite.spriteFrame.setTexture(texture2d);
        this.texture2d = texture2d;
    },

    putInContainer: function putInContainer(dom) {
        this.scalex = this.width / this.node.width;
        this.scaley = this.height / this.node.height;

        var div = document.createElement("div");
        this.container = div;
        //div.style.zIndex = '-1';
        //div.style = "position:absolute;zIndex:'-1';overflow:'hidden';"
        div.style.position = 'relative';
        div.style.overflow = 'hidden';
        div.appendChild(dom);

        var div = document.createElement("div");
        this.iframe = div;
        div.style.position = 'absolute';

        div.style.overflow = 'hidden';

        div.appendChild(this.container);

        var gamediv = document.getElementById("Cocos2dGameContainer"); //Cocos2dGameContainer//GameDiv
        this.gamediv = gamediv;

        this.resizeContainer();

        gamediv.parentNode.insertBefore(div, gamediv.parentNode.firstChild);
        //document.body.appendChild(div);
        this.resizeEventVar = this.resizeEvent.bind(this);
        window.addEventListener("resize", this.resizeEventVar, false);
    },
    resizeEvent: function resizeEvent(e) {
        e.preventDefault();
        this.resizeContainer();
    },
    setSize: function setSize(x, y, width, height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.scalex = this.width / this.node.width;
        this.scaley = this.height / this.node.height;
        this.resizeContainer();
    },

    resizeContainer: function resizeContainer() {
        var div = this.container;
        var gamediv = this.gamediv;
        div.style.left = this.x * this.scalex + "px";
        div.style.top = this.y * this.scaley + "px";
        var w = this.scalex * Number(gamediv.style.width.replace("px", ""));
        var h = this.scaley * Number(gamediv.style.height.replace("px", ""));
        div.style.width = w + "px";
        div.style.height = h + "px";
        //div.style.margin = gamediv.style.margin;
        //div.style.padding = gamediv.style.padding;

        this.iframe.style.width = gamediv.style.width;
        this.iframe.style.height = gamediv.style.height;
        //this.iframe.style.margin = gamediv.style.margin;
        this.iframe.style.margin = gamediv.style.padding;
        //div.style.transform = gamediv.style.transform

        //var s = this.video.width / w;
        //var y = s * h / this.video.height;
        //y = y < 1 ? 1 : y;
        //this.video.style.transform = 'matrix(1, 0, 0,' + y + ', 0, 0)';
    },

    paintVideo: function paintVideo(dt) {
        if (cc._renderType === cc.game.RENDER_TYPE_CANVAS) {
            return;
        }
        if (!this.video) {
            //return;
        }

        this.dt += dt;
        if (this.dt < 0.03) {
            return;
        }
        this.dt = 0;

        //this.player.glapha.drawImage(this.player.video, 0, 0, this.player.video.width / 2, this.player.video.height / 2);
        //webgl模式
        //this.texture2d.handleLoadedTexture();
    }

});

var flvPlayer = function flvPlayer(hasAudio) {
    this.hasAudio = hasAudio;
    var video = document.createElement("video");
    this.video = video;
    video.width = 480;
    video.height = 270;

    //this.video.src = "http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4";
    //video.controls = true;
    video.muted = true;
    video.autoplay = true;
    //video.setAttribute('muted', '');
    //video.setAttribute('autoplay', '');
    video.setAttribute("playsinline", '');
    video.setAttribute("webkit-playsinline", "");
    video.setAttribute("x5-video-player-type", "h5");

    //video.setAttribute('crossorigin', 'anonymous');
    //video.setAttribute('preload', '');

    //video.style.display = "none";
    //video.style = "width:100%; height:100%;object-fit:fill;"
    video.style.width = '100%';
    video.style.height = '100%';
    video.style.objectFit = 'fill';

    //cc.view.setResizeCallback(function() { cc.log(gamediv.style.width); });
    var self = this;

    video.oncanplay = function () {
        var vw = video.videoWidth || 480;
        var vh = video.videoHeight || 270;
        video.width = vw;
        video.height = vh;
        self.err = false;
        cc.log("video load", vw, vh);
        //video.play();

        //var texture2d = new cc.Texture2D();
        //texture2d.initWithElement(video);
        //texture2d.handleLoadedTexture();
        //sprite.spriteFrame.setTexture(texture2d);
        //self.texture2d = texture2d;
    };

    video.onpause = function () {
        console.log("onpause ");
        if (self.err) {
            return;
        }
        self.replay();
    };

    flvjs.LoggingControl.enableAll = false;
};
flvPlayer.prototype = {
    play: function play(url) {
        if (url != null) {
            this.url = 'http://' + url;
        }
        url = this.url;
        this.stop();
        var player = flvjs.createPlayer({
            type: 'flv',
            url: url,
            hasAudio: false
        }, {
            isLive: true,
            enableWorker: true,
            enableStashBuffer: false,
            stashInitialSize: 128,
            autoCleanupSourceBuffer: true

        });
        this.player = player;

        player.attachMediaElement(this.video);
        player.load();

        var self = this;
        player.on(flvjs.Events.MEDIA_INFO, function (args) {
            console.log("MEDIA_INFO:" + self.video.paused);
            if (self.video.paused && self.player.buffered.length > 0) {
                self.replay();
            }
        });
        player.on(flvjs.Events.ERROR, function (arg) {
            self.onError(arg);
        });
        player.on(flvjs.Events.LOADING_COMPLETE, function (arg) {
            self.onError(arg);
        });
        player.on(flvjs.Events.RECOVERED_EARLY_EOF, function (arg) {
            self.onError(arg);
        });
    },

    stop: function stop() {
        var player = this.player;
        if (player != null) {
            player.pause();
            player.unload();
            player.detachMediaElement();
            player.destroy();
            this.player = null;
        }
    },

    replay: function replay() {
        console.log("replay ");
        this.err = false;
        this.player.currentTime = this.player.buffered.end(0) - 0.01;
        var p = this.player.play();
        var self = this;
        p.catch(function (v) {
            console.log(v);
            self.err = true;
        });
    },

    reload: function reload() {
        var self = this;
        setTimeout(function () {
            self.play(self.url);
        }, 3000);
    },

    onError: function onError(arg) {
        console.log("flv onError:" + arg);
        this.reload();
    },
    destroy: function destroy() {
        this.stop();
    }
};

module.exports = livePlayer;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=livePlayer.js.map
        