(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/player/AmPlayer.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'a72c2LnFx9OfKhdnHukO5E1', 'AmPlayer', __filename);
// Script/player/AmPlayer.js

'use strict';

var amPlayer = function amPlayer(hasAudio) {
    this.hasAudio = hasAudio;
    var video = document.createElement("canvas");
    this.video = video;

    video.style.backgroundColor = '0D0E1B';
    video.style.width = '100%';
    video.style.height = '100%';
    this.player = null;
};

amPlayer.prototype = {
    init: function init() {
        var self = this;
        var player = this.player;
        if (!player) {
            player = new Module.AnPlayer();
            this.player = player;
            player.onOpen = function (arg) {
                out("onOpen");
                //var name = url.value.split("/")[4];
                //player.send("[\"__play\",\"" + name + "\"]");           
            };
            player.onClose = function (arg) {
                out("onClose");
                setTimeout(function () {
                    self.play();
                }, 3000);
            };
            player.onMessage = function (arg) {
                console.log(arg);
            };

            player.bufferTime = 500;
            player.hasAudio = false;
            player.setCanvas(this.video);
        }
    },
    stop: function stop() {
        var player = this.player;
        if (player) {
            player.stop();
        }
    },
    play: function play(url) {
        this.init();
        if (url != null) {
            this.url = 'ws://' + url;
        }

        this.player.connect(this.url);
    }

};

out = function out(e) {
    //document.getElementById("log").innerHTML += e + "<br>";
    console.log(e);
};

if (typeof module != 'undefined') {
    module.exports = amPlayer;
};

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=AmPlayer.js.map
        