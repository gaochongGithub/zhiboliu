(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/helloworld.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '280c3rsZJJKnZ9RqbALVwtK', 'helloworld', __filename);
// Script/helloworld.js

'use strict';

//如果是发布webgl需要在main.js的加入一句
//cc.macro.ENABLE_TRANSPARENT_CANVAS = true; //cc.game.run(option, onStart);这之前
//Decoder.js,flv.min.js导入为插件,其他文件为require
//发布选择canvas模式
var livePlayer = require("livePlayer");

cc.Class({
    extends: cc.Component,

    properties: {
        btnplay: {
            default: null,
            type: cc.Button
        },
        btnstop: {
            default: null,
            type: cc.Button
        },
        btnchange: {
            default: null,
            type: cc.Button
        }

    },

    // use this for initialization
    onLoad: function onLoad() {
        cc._initDebugSetting(cc.DebugMode.INFO);
        this.btnplay.node.on('click', this.onclick, this);
        this.btnstop.node.on('click', this.onclick, this);
        this.btnchange.node.on('click', this.onclick, this);
        //console.log(cc.url.raw('Script/player/Decoder.js'))
        //this.liveVideo = this.node.getComponent("livePlayer");

        this.liveVideo = this.node.addComponent(livePlayer);
        this.liveVideo.setSize(-60, 0, 960, 640);

        //第二个
        //this.liveVideo2 = this.node.addComponent(livePlayer);
        this.home = 1;

        var self = this;
        setTimeout(function () {
            self.liveVideo.play("tw.002cdn.com/obs/02M.flv");
        }, 1000);
    },

    update: function update(dt) {},

    onclick: function onclick(event) {
        var url = "23.99.125.208:8081/gw/";
        var btn = event.detail;
        if (btn == this.btnplay) {
            //this.liveVideo.play(url +"bjl012.flv");
            this.liveVideo.play("tw.002cdn.com/obs/02M.flv");
            this.home = 1;
        } else if (btn == this.btnstop) {
            this.liveVideo.stop();
        } else if (btn == this.btnchange) {
            //换房间
            //cc.director.loadScene("helloworld");
            this.home = this.home % 6 + 1;
            if (this.home == 5) {
                this.liveVideo.play(url + "bjl0" + this.home + "11.flv");
                return;
            }
            this.liveVideo.play(url + "bjl0" + this.home + "1.flv");
        }
        //this.liveVideo.play("ws://tw.002cdn.com/obs/02M.flv");
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=helloworld.js.map
        