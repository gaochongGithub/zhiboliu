var amPlayer = function (hasAudio) {
    this.hasAudio = hasAudio;
    var video = document.createElement("canvas");
    this.video = video;

    video.style.backgroundColor = '0D0E1B';
    video.style.width = '100%';
    video.style.height = '100%';
    this.player = null;
    
};

amPlayer.prototype = {
     init:function(){
         var self = this;
        var player = this.player;
        if(!player){
            player = new Module.AnPlayer();
            this.player = player;
            player.onOpen = function(arg){
                out("onOpen");
                //var name = url.value.split("/")[4];
                //player.send("[\"__play\",\"" + name + "\"]");           
            }
            player.onClose= function(arg){
                out("onClose");
                setTimeout(function(){
                    self.play();
                },3000)
            }
            player.onMessage= function(arg){
                console.log(arg); 
            }
        
            player.bufferTime = 500;
            player.hasAudio = false;
            player.setCanvas(this.video);

        }
    },
    stop: function () {
        var player = this.player;
        if(player){
            player.stop();
        }			
    },
    play: function (url) {
        this.init();
        if (url != null) { this.url = 'ws://' + url; }
        
        this.player.connect(this.url);
    },

};

out = function(e){
    //document.getElementById("log").innerHTML += e + "<br>";
    console.log(e);
};

if (typeof module != 'undefined') {
    module.exports = amPlayer;
};